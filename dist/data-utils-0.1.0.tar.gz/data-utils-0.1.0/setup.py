# -*- coding: utf-8 -*-
from distutils.core import setup

packages = \
['data_utils']

package_data = \
{'': ['*']}

install_requires = \
['dask>=2.5,<3.0',
 'distributed>=2.5,<3.0',
 'pandas>=0.25.1,<0.26.0',
 'torch>=1.2,<2.0']

setup_kwargs = {
    'name': 'data-utils',
    'version': '0.1.0',
    'description': 'A set of generic, useful data science and machine learning methods.',
    'long_description': None,
    'author': 'AndreCNF',
    'author_email': 'andrecnf@gmail.com',
    'url': 'https://github.com/andrecnf/data_utils',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
