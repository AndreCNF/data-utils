# -*- coding: utf-8 -*-
from distutils.core import setup

packages = \
['data_utils']

package_data = \
{'': ['*']}

install_requires = \
['comet-ml>=2.0,<3.0',
 'comet_ml>=2.0,<3.0',
 'dask>=2.5,<3.0',
 'distributed>=2.5,<3.0',
 'everett>=1.0,<2.0',
 'fsspec>=0.6.0,<0.7.0',
 'modin>=0.7.0,<0.8.0',
 'pandas>=0.25.1,<0.26.0',
 'pdoc3>=0.7.2,<0.8.0',
 'portray>=1.3,<2.0',
 'ray==0.8.1',
 'sklearn>=0.0.0,<0.0.1',
 'sphinx>=2.2,<3.0',
 'torch>=1.2,<2.0',
 'tqdm>=4.38,<5.0']

setup_kwargs = {
    'name': 'data-utils',
    'version': '0.1.0',
    'description': 'A set of generic, useful data science and machine learning methods.',
    'long_description': None,
    'author': 'AndreCNF',
    'author_email': 'andrecnf@gmail.com',
    'url': 'https://github.com/andrecnf/data_utils',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.6,<4.0',
}


setup(**setup_kwargs)
